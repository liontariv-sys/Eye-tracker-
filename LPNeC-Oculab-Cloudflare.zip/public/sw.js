const CACHE = "lpnec-oculab-v2";
const APP_SHELL = ["/", "/manifest.webmanifest", "/favicon.svg", "/favicon-32.png", "/icon-192.png", "/icon-512.png", "/brand/lpnec-logo-transparent.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)))));
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  if (event.request.mode === "navigate") {
    event.respondWith(fetch(event.request).then((response) => {
      if (url.pathname === "/" && response.ok && !response.redirected) {
        const copy = response.clone();
        caches.open(CACHE).then((cache) => cache.put("/", copy));
      }
      return response;
    }).catch(() => url.pathname === "/" ? caches.match("/") : Response.error()));
    return;
  }

  event.respondWith(caches.match(event.request).then((cached) => cached ?? fetch(event.request).then((response) => {
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE).then((cache) => cache.put(event.request, copy));
    }
    return response;
  })));
});
